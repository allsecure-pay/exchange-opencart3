<?php

namespace AllsecureExchange\Client\Exception;

/**
 * Class ClientException
 *
 * @package AllsecureExchange\Client\Exception
 */
class ClientException extends \Exception {

}
