<?php
// Breadcrumb
$_['text_extension'] = 'Extensions';

// Admin Panel
$_['heading_title'] = 'AllSecure Exchange';
