<?php


namespace AllsecureExchange\Client\Data\Result;

/**
 * Class ResultData
 *
 * @package AllsecureExchange\Client\Data\Result
 */
abstract class ResultData {

    /**
     * @return array
     */
    abstract public function toArray();

}
