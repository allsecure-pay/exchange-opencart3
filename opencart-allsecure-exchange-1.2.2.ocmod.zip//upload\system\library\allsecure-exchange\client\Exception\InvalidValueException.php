<?php

namespace AllsecureExchange\Client\Exception;

/**
 * Class InvalidValueException
 *
 * @package AllsecureExchange\Client\Exception
 */
class InvalidValueException extends ClientException {

}
