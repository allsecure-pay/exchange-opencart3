<?php


namespace AllsecureExchange\Client\Http\Exception;

/**
 * Class ClientException
 *
 * @package AllsecureExchange\Client\Http\Exception
 */
class ClientException extends \Exception {

}
