<?php

namespace AllsecureExchange\Client\Exception;

/**
 * Class TimeoutException
 *
 * @package AllsecureExchange\Client\Exception
 */
class TimeoutException extends ClientException {

}
